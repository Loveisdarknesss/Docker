# Docker-for-beginners-practical-experience

## Course sourse

[Docker for beginners](https://stepik.org/course/123300/info)
